#!/usr/bin/env python3
"""Validate the opsctl architectural/effect boundary after PF-1.

opsctl is the project-specific policy/projection engine. Provider/network/process authority
remains forbidden. PF-1 adds exactly one bounded repository effect: atomic replacement of the
canonical architecture inventory generated projection.
"""
from __future__ import annotations
import argparse, copy, json, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'tools/opsctl/src'
CARGO=ROOT/'tools/opsctl/Cargo.toml'
OPERATOR=ROOT/'architecture/operator-contract.json'
ALLOWED_WRITE_FILE='architecture/inventory.rs'
REQUIRED_FILES={
 'architecture/mod.rs','architecture/model.rs','architecture/authorities.rs','architecture/inventory.rs',
 'canonical.rs','cli.rs','lib.rs','repository.rs','release/digest.rs'
}
FORBIDDEN_RUNTIME=('Command::new(', 'std::process::Command', 'reqwest::', 'ureq::', 'worker::', 'cloudflare::', 'std::net::', 'TcpStream', 'api_token', 'secret_access_key')
WRITE_MARKERS=('OpenOptions','write_all(','fs::rename(','sync_all(')
FORBIDDEN_LIFECYCLE=('architecture/accepted/','git tag','tag --list','acceptedTagRecords','parseTagMessage','refs/tags/')

class GateError(ValueError): pass
def fail(m:str): raise GateError(m)
def sources(root=ROOT):
    out={}
    base=root/'tools/opsctl/src'
    for p in sorted(base.rglob('*.rs')):
        out[p.relative_to(base).as_posix()]=p.read_text(encoding='utf-8')
    return out

def validate(root=ROOT):
    s=sources(root)
    missing=REQUIRED_FILES-set(s)
    if missing: fail(f'modular opsctl source layout incomplete: {sorted(missing)}')
    prod='\n'.join(v.split('#[cfg(test)]',1)[0] for v in s.values())
    for marker in FORBIDDEN_RUNTIME:
        if marker in prod: fail(f'forbidden runtime/provider/process marker: {marker}')
    arch='\n'.join(v.split('#[cfg(test)]',1)[0] for k,v in s.items() if k.startswith('architecture/'))
    for marker in FORBIDDEN_LIFECYCLE:
        if marker in arch: fail(f'second lifecycle derivation marker: {marker}')
    if '.github/scripts/architecture-acceptance.mjs derive' not in arch:
        fail('canonical lifecycle deriver input boundary missing')
    for path,text in s.items():
        production=text.split('#[cfg(test)]',1)[0]
        observed=[m for m in WRITE_MARKERS if m in production]
        if observed and path != ALLOWED_WRITE_FILE:
            fail(f'unbounded repository write capability in {path}: {observed}')
    writer=s[ALLOWED_WRITE_FILE]
    for marker in ('INVENTORY_PATH','OpenOptions','create_new(true)','write_all(','flush()','sync_all()','fs::rename(','read-back'):
        if marker not in writer: fail(f'PF-1 atomic writer lost marker: {marker}')
    if '--output' in s['cli.rs']:
        # it may appear only in the explicit negative test string/message, never as supported parser branch.
        if re.search(r'"--output"\s*=>', s['cli.rs']): fail('arbitrary inventory output path became supported')
    if 'scripts/generate-architecture-inventory.py' in prod or 'generate-architecture-inventory-engine.py' in prod:
        fail('retired Python inventory path remains reachable from opsctl')
    cargo=(root/'tools/opsctl/Cargo.toml').read_text(encoding='utf-8')
    if 'serde = { version = "=1.0.229", features = ["derive"] }' not in cargo or 'serde_json = "=1.0.151"' not in cargo:
        fail('typed/canonical JSON dependencies are not exact pinned')
    canonical=s['canonical.rs']; digest=s['release/digest.rs']
    if 'pub fn canonical_json' not in canonical or 'pub fn sha256_hex' not in canonical:
        fail('shared canonical JSON/SHA-256 primitive missing')
    if 'pub use crate::canonical' not in digest or 'pub fn canonical_json' in digest:
        fail('release must reuse, not duplicate, shared canonical primitive')
    op=json.loads((root/'architecture/operator-contract.json').read_text(encoding='utf-8'))
    surfaces=op.get('operator_surfaces',{})
    writes=[]
    for sid,entry in surfaces.items():
        effect=entry.get('repository_workspace_effect','NONE')
        if effect=='GENERATED_PROJECTION_WRITE': writes.append(sid)
        elif effect!='NONE': fail(f'unknown repository effect {effect} for {sid}')
        for key in ('network_authority','provider_mutation_authority','secret_readback'):
            if entry.get(key) is not False: fail(f'{sid} gained forbidden {key}')
    if writes != ['architecture_inventory_write']:
        fail(f'exactly one generated projection writer required, observed={writes}')
    write=surfaces[writes[0]]
    if write.get('fixed_write_target')!='architecture/inventory.json' or write.get('side_effects')!='GENERATED_PROJECTION_WRITE':
        fail('inventory writer effect/fixed target contract drifted')
    for action in ('render','check','inspect'):
        e=surfaces.get(f'architecture_inventory_{action}')
        if not isinstance(e,dict) or e.get('repository_workspace_effect')!='NONE' or e.get('side_effects')!='NONE':
            fail(f'{action} must remain no-write')
    for predecessor in ('scripts/generate-architecture-inventory.py','scripts/generate-architecture-inventory-engine.py'):
        if (root/predecessor).exists(): fail(f'retired predecessor must be absent: {predecessor}')
    for wf in (root/'.github/workflows').glob('*.y*ml'):
        txt=wf.read_text(encoding='utf-8')
        if 'generate-architecture-inventory.py' in txt or 'generate-architecture-inventory-engine.py' in txt:
            fail(f'current CI still calls retired predecessor: {wf.relative_to(root)}')
    return {'repository_workspace_writers':writes,'network_authority':False,'provider_mutation':False,'production_mutation':False}

def self_test():
    report=validate()
    assert report['repository_workspace_writers']==['architecture_inventory_write']
    op=json.loads(OPERATOR.read_text(encoding='utf-8'))
    bad=copy.deepcopy(op); bad['operator_surfaces']['doctor']['repository_workspace_effect']='GENERATED_PROJECTION_WRITE'
    # Direct policy-level negative without mutating repository.
    writes=[k for k,v in bad['operator_surfaces'].items() if v.get('repository_workspace_effect','NONE')=='GENERATED_PROJECTION_WRITE']
    if writes==['architecture_inventory_write']: fail('duplicate-writer negative fixture unexpectedly passed')
    print('opsctl effect-boundary negative matrix passed')

def main():
    p=argparse.ArgumentParser(); p.add_argument('--self-test',action='store_true'); a=p.parse_args()
    if a.self_test: self_test(); return 0
    print(json.dumps(validate(),sort_keys=True)); return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except (GateError, OSError, json.JSONDecodeError) as e:
        print(f'opsctl architectural boundary check failed: {e}', file=__import__('sys').stderr); raise SystemExit(1)

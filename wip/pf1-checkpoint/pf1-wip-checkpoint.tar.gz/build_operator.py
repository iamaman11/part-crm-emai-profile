import json
from collections import OrderedDict
from pathlib import Path

def surface(command, namespace, action, owner, source, input_class, output, parser, *, mode='READ_ONLY_METADATA_ONLY', side='NONE', repo_effect='NONE', fixed=None):
    d=OrderedDict(command=command, namespace=namespace, action=action, status='ACTIVE', activation_owner=owner, source=source, input_class=input_class, output_semantics=output, mode=mode, side_effects=side, repository_workspace_effect=repo_effect, network_authority=False, provider_mutation_authority=False, secret_readback=False)
    if fixed is not None: d['fixed_write_target']=fixed
    d['parser_probe_args']=parser
    return d

s=OrderedDict()
s['doctor']=surface('opsctl doctor','root','doctor','AR-6','canonical subject-domain validators','repository metadata and canonical authorities','deterministic validation metadata',['doctor'])
s['status']=surface('opsctl status','root','status','AR-6','docs/status.json','repository metadata','canonical status JSON passthrough',['status'])
for action in ['render','check','write','inspect']:
    key=f'architecture_inventory_{action}'
    write=action=='write'
    s[key]=surface(f'opsctl architecture inventory {action}','architecture.inventory',action,'POST_AR11_PF1','architecture/architecture-inventory-static-authority.json + canonical typed authorities + canonical derived lifecycle input','canonical repository/domain authorities plus versioned output of .github/scripts/architecture-acceptance.mjs derive',
        {'render':'canonical deterministic ArchitectureInventory bytes','check':'exact semantic/byte drift diagnostics; no mutation','write':'atomic fixed-target generated projection activation with read-back equality proof','inspect':'current/drifted/invalid inventory inspection metadata'}[action],
        ['architecture','inventory',action,'--lifecycle-json','lifecycle.json'],
        mode='BOUNDED_GENERATED_PROJECTION_WRITE' if write else 'READ_ONLY_METADATA_ONLY',
        side='GENERATED_PROJECTION_WRITE' if write else 'NONE',
        repo_effect='GENERATED_PROJECTION_WRITE' if write else 'NONE',
        fixed='architecture/inventory.json' if write else None)
s['credentials_status']=surface('opsctl credentials status','credentials','status','AR-8','architecture/credential-lifecycle.json','credential lifecycle metadata','metadata-only credential lifecycle projection',['credentials','status'])
s['credentials_rotation_plan']=surface('opsctl credentials rotation-plan','credentials','rotation-plan','AR-8','architecture/operator-contract.json','credential lifecycle and operator metadata','deterministic rotation and recovery metadata plan',['credentials','rotation-plan'])
for act, out in [('status','deterministic ledger classification'),('plan','deterministic no-mutation migration or rollback plan'),('compatibility','deterministic runtime and schema compatibility decision'),('verify','deterministic post-apply verification metadata')]:
    parser=['d1',act,'--component','catalog','--ledger-json','ledger.json']
    if act!='status': parser += ['--release-manifest','release.json']
    s[f'd1_{act}']=surface(f'opsctl d1 {act}','d1',act,'AR-9','architecture/d1-evolution-ar9.json','saved D1 ledger metadata and canonical migration/release schema contracts',out,parser)
for act, inputc,out,extra in [
    ('inspect','immutable Release Set metadata','deterministic Release Set inspection metadata',[]),
    ('verify','immutable Release Set metadata and local artifact bytes','deterministic Release Set and artifact identity verification',['--artifact-root','artifacts']),
    ('compatibility','Release Set, capability profile, environment and saved evidence metadata','deterministic release compatibility decision',['--profile','rehearsal-core-v1','--environment','rehearsal','--evidence-json','evidence.json'])]:
    s[f'release_{act}']=surface(f'opsctl release {act}','release',act,'AR-11','architecture/release-architecture-ar11.json',inputc,out,['release',act,'--release-set','release-set.json',*extra])
for act,out in [('plan','deterministic no-mutation transition plan'),('preflight','fail-closed metadata-only preflight before provider credential exposure'),('verify','deterministic post-mutation observed-state verification without mutation authority')]:
    s[f'promotion_{act}']=surface(f'opsctl promotion {act}','promotion',act,'AR-11','architecture/release-architecture-ar11.json','Release Set, profile, environment, saved deployment snapshot and evidence metadata',out,['promotion',act,'--release-set','release-set.json','--profile','rehearsal-core-v1','--environment','rehearsal','--snapshot','snapshot.json','--evidence-json','evidence.json'])

root=OrderedDict(
 schema_version=1, kind='OPERATOR_CONTRACT_AUTHORITY', status='current',
 credential_authority='architecture/credential-authority.json', credential_lifecycle='architecture/credential-lifecycle.json', profile_security='architecture/profile-security.json', historical_rehearsal_provenance='architecture/ar8-operator-rehearsal.json',
 mode='BOUNDED_METADATA_AND_GENERATED_PROJECTION_WRITE',
 command_registry_policy=OrderedDict(authority='architecture/operator-contract.json::operator_surfaces',implementation='tools/opsctl/src/cli.rs',active_authority_to_implementation_parity_required=True,active_implementation_to_authority_parity_required=True,reserved_namespaces_must_not_parse=True,provider_credentials_allowed=False,child_process_provider_execution_allowed=False,network_provider_execution_allowed=False,database_mutation_allowed=False,production_mutation_allowed=False,generated_projection_write_allowed=True,generated_projection_write_fixed_targets=['architecture/inventory.json']),
 invariants=OrderedDict(secret_readback=False,direct_secret_mutation=False,provider_mutation=False,database_mutation=False,deployment_mutation=False,customer_state_mutation=False,second_credential_authority=False,routine_release_secret_transport=False,production_mutation=False),
 operator_surfaces=s,
 reserved_namespaces=[
  OrderedDict(namespace='credentials',actions=['readiness'],status='RESERVED',activation_owner='AR-13',parser_probe_args=[['credentials','readiness']],provider_mutation_authority=False,network_authority=False,production_authorization_authority=False),
  OrderedDict(namespace='recovery',actions=['inspect','plan','verify'],status='RESERVED',activation_owner='AR-14',parser_probe_args=[['recovery','inspect'],['recovery','plan'],['recovery','verify']],provider_mutation_authority=False,network_authority=False,production_authorization_authority=False),
  OrderedDict(namespace='readiness',actions=['readiness'],status='RESERVED',activation_owner='AR-16',parser_probe_args=[['readiness']],provider_mutation_authority=False,network_authority=False,production_authorization_authority=False),
 ],
 audit_lineage=OrderedDict(mode='metadata-only',allowed_fields=['identity','concern_id','version','state','environment','binding_names','provider_metadata_identifier','source_sha','evidence_reference','timestamp'],forbidden_fields=['value','secret_value','plaintext','plaintext_value','private_key','password','token_value','credential_value','key_material','raw_secret','raw_token','raw_handle']),
 ceremony_policy=OrderedDict(stage_order=['precheck','issue_or_import','bind_replacement','switch_active','verify','retire_previous'],retirement_rule='VERIFY_REPLACEMENT_BEFORE_RETIRE_PREVIOUS',rollback_rule='KEEP_PREVIOUS_VALID_OR_RETAINED_UNTIL_REPLACEMENT_IS_VERIFIED',cross_environment_rule='TARGET_ENVIRONMENT_IDENTIFIERS_MUST_MATCH_BEFORE_ANY_CEREMONY',recovery_required=True),
 required_negative_cases=['missing_binding','malformed_keyring','unknown_version','revoked_version','stale_rotation','concurrent_rotation','interrupted_reconciliation','secret_leakage','competing_mutator','routine_deploy_secret_transport','environment_cross_binding','revoke_before_verify'],
 profile_security_visibility=OrderedDict(mode='METADATA_ONLY',raw_secret_handle=False,raw_device_key_handle=False,entropy_bytes=False,enrollment_claim_value=False,object_access_bearer=False)
)
Path('/tmp/pf1/architecture/operator-contract.json').write_text(json.dumps(root,indent=2)+"\n")
print(len(s), Path('/tmp/pf1/architecture/operator-contract.json').stat().st_size)
